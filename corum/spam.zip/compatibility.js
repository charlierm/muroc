gloader.load(["glow", "1", "glow.dom", "glow.embed"], {
    onLoad: function(glow){
    
		/**
		* @namespace Namespace for legacy EMP_FMTJ. This is now <b>deprecated</b>
		* and is now only supported for legacy applications.  New application
		* <b>MUST</b> use {@link bbc.fmtj.av.emp} 
		*
		**/	
        emp_load = {};
		
		/**
		 * @deprecated supported only for legacy applications.
		 * 
		 * array to hold the id's of players created using
		 * the legacy method getEmpEmbeddedParams()
		 */
		emp_load.playerInstances = [];
        
		/**
		 * @deprecated supported only for legacy applications.
		 * 
		 * This is a legacy property that defines whether emp's are 
		 * written when the dom is ready. This was always
		 * set to true.
		 */
        emp_load.isEmpWrittenOnLoad = true;
		
		
		
		/**
		 * @deprecated supported only for legacy applications.
		 * 
		 * @name emp_load.getEmpEmbeddedParams
		 * @function
		 * @description adds a dom id to the list of legacy player instances
		 * 			  
		 * @param {string} domId 
		 * 
		 */
    emp_load.getEmpEmbeddedParams = function(domId){
    
        emp_load.playerInstances.push(domId);
        
    }
        
    /**
		 * @deprecated supported only for legacy applications.
		 * 
		 * @name emp_load.isFlashVersionValid
		 * @function
		 * @description Determines whether the flash version in the browser meets
		 * a minimum version.
		 * 			  
		 * @param version {String} The minimum version of flash. [Default is 8]
		 * 
		 */
      emp_load.isFlashVersionValid = function( version ) {
        var v       = version || "8"; // The min version of flash supported
        var valid   = true;
			
        if(v != null) {
            var detection = glow.embed.Flash.version(); 
            var assets = [ detection.major, detection.minor, detection.release ];
				
            if (typeof(v) == 'number') {
							v = v.toString()
						}
				
            var targets = v.split(".");
				
            for(var i = 0; i < targets.length; ++i) {
                var target = parseInt(targets[i]);
				
					
                if(i < assets.length) {
                    // asset versioning contains this index
                    // do comparison
                    // if they're equal, continue to check subsequent indices
                    var asset = parseInt(assets[i]);
                    if(target > asset) {
                        valid = false;
                        break;
                    } else if (asset > target) {
                        // valid = true; (default)
                        break;
                    }	
                } else {
                    // asset versioning doesn't contain this particular index
                    // so if targets[i] > 0, the asset isn't valid
                    // if it's valid, continue to check subsequent indices
                    if(target > 0) {
                      valid = false;
                      break;
                    }
                }
					
					// if whole loop is ending and valid has not been set to false,
					// then valid=true (default)
				}
			}
			
			return valid;
		}
    
		/**
		 * @deprecated supported only for legacy applications.
		 * 
		 * @name emp_load.writeAllEmpContent
		 * @function
		 * @description iterates through the player instances array and invokes
		 * 				the loadEmp method to grab the object/param tags from the
		 * 				page and embed them.
		 * 
		 */
        emp_load.writeAllEmpContent = function(){
            bbc.fmtj.av.emp.load(function(){
                for (var i = 0; i < emp_load.playerInstances.length; i++) {
                    bbc.fmtj.av.emp.loadEmp(emp_load.playerInstances[i]);
                }
            })
            
        }
    
    /**
		 * @deprecated supported only for legacy applications.
		 * 
		 * @name emp_load.displayEMP
		 * @function
		 * @description Loads an EMP based on an object of properties.
		 *
		 * @param empToLoad {Object} Object of properties for EMP. Currently
		 *  supported properties are:
		 * @param empToLoad.domId       {String} The co